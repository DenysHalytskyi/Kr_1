let a = document.getElementById("input1")
let b = document.getElementById("input2")
let button = document.getElementById("but")
button.addEventListener("click",()=> {

});


//1
/*
let num=10;
let num2=5;
console.log(num+num2);
console.log(num-num2);
console.log(num*num2);
console.log(num/num2);
 */

//2
/*
let arr=[1,2,3,4,5];
for(let i=0;i<arr.length;i++)
    console.log(arr[i]);
 */

//3
/*
function suma(a, b)
{
console.log(a+b);
}
suma(5,7);
 */

//4
/*
function fib(n)
{
    let arr=[0, 1];
    for (let i=2;i<n;i++)
        arr[i] = arr[i - 2] + arr[i - 1];
    return arr
}
console.log(fib(10));
 */








